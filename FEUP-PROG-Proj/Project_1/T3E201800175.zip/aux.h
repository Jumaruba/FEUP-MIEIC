//
// Created by maruba on 18-03-2019.
//

#ifndef UNTITLED_AUX_H
#define UNTITLED_AUX_H
#include <string>
#include <vector>
#include <iostream>


//FUNCTION--------------------------------------------------------------------------------------------------------------

int isInt();                                        //checks if the input is int
bool proceed();	                                    //asks the user if it wanna proceed the action
int cin_menu(int superior, int inferior);	        //checks the correct input for menu
void trimRight(std::string &s);	                    //eliminaets spaces on the right
void trimLeft (std::string &s);	                    //eliminates spaces on the left
void trim(std::string &s);	                        //eliminates spaces on the right and left
std::string maiusculo(std::string m);	            //transform a string to upper case
void duplicate(std::vector <std::string>& m);       //eliminates duplicated items of vectors
void clear_screen();                                //clear the screen for windows and linux
float isFloat();	                                //checks if the input is float
std::string valid_yes();                            //for a question of [y|n] checks if the input is valid

#endif //UNTITLED_AUX_H
