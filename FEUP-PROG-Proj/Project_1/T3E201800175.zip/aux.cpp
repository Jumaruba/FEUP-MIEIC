#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include "aux.h"

using namespace std;

//FUNCTION--------------------------------------------------------------------------------------------------------------

int isInt() {  //input for int numbers
    int provisorio;

    do {
        if (cin >> provisorio) {   //checks if number is int
            return provisorio;     //if it's int, then return the number
        } else {
            cin.clear();           //if it's not int, then clear the flag
            cin.ignore(1000, '\n'); //ignore what is inside the cin
            cout << "Invalid input. Try again: "; //the user will input again
        }
    } while (true);

}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

float isFloat() {  //input for int numbers
    float provisorio;

    do {
        if (cin >> provisorio) {   //checks if number is float
            return provisorio;     //if it's int, then return the number
        } else {
            cin.clear();           //if it's not int, then clear the flag
            cin.ignore(1000, '\n'); //ignore what is inside the cin
            cout << "Invalid input. Try again: "; //the user will input again
        }
    } while (true);

}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//read valid information for the menu

int cin_menu(int superior, int inferior)
{
    int menu_option;  //menu typed by the user
    bool validNumber = false;   //if the range of the number is valid or it's not an integer

    cout << endl
         << "Type the desired option: ";
    do
    {                                                                   // Treatment of invalid inputs
        if (cin >> menu_option)                                         //  If it's integer
        {
            if (menu_option <= superior && menu_option >= inferior)     //if it's in the correct range
                validNumber = true;                                     //then it's a valid input
            else
            {                                                           //if it's invalid input range
                cin.clear();                                            //clear the flag
                cin.ignore(1000, '\n');                                 //ignore the previous information at cin
                cout << "Invalid input. Try again: ";                   // try again
            }
        }
        else
        {
            cin.clear();                                            // if it's not an integer, clear the flag
            cin.ignore(1000, '\n');                                 // ignore the previous information at cin
            cout << "Invalid input. Try again: ";                   // try again
        }
    } while(!validNumber);                                          // while the input is not valid, repeat the action of reading
    return menu_option;
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//ask the user if he wanna proceed the action. Only accepts y or n.

bool proceed() {                //checks if the user wanna proceed with the action;
    bool repeat = true;         //while it's not a valid input
    string aux;                 //stores the information given by the user
    cout << "Wanna proceed?[y|n] ";
    do {
        if (cin >> aux) {                               //if it's a string
            aux = maiusculo(aux);                       //then put all the string as an upper case string
            if (aux != "Y" && aux != "N") {             //if the string is not Y or N, then the input is still invalid (repeat = true)
                cout << "Invalid input. Try again [y|n]: ";
            } else {
                if (aux == "Y")                         //if it's Y, the user wanna proceed
                    return true;
                else
                    return false;                       //if not, the user dont wanna proceed
            }
        }
        else
            cout << "Invalid input. Try again [y|n]: ";
    } while (repeat);
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//remove right spaces

void trimRight(string &s){
    s.erase(0,s.find_first_not_of(' '));
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//remove left spaces

void trimLeft(string &s){
    s.erase(s.find_last_not_of(' ')+1);
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//remove the left and right spaces;

void trim(string &s){
    trimLeft(s);
    trimRight(s);
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//changes string by string to upper case

string maiusculo(const string m){  //change a string to upper case
    string aux;
    for (int i = 0; i< m.size(); i++){
        aux.push_back(toupper(m[i]));
    }
    return aux;
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

// remove duplicaded items in a vector

void duplicate(vector <string>& m){

    vector<string>::iterator it;

    sort(m.begin(),m.end());     //sort the vector
    it = unique(m.begin(),m.end());  //remove repeated items that are shown together
    m.resize(distance(m.begin(), it));   //resize the vector

}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//clear screen at linux and windows interface;

void clear_screen() {
#ifdef WINDOWS
    std::system("cls");
#else
    // Assume POSIX
    std::system("clear");
#endif
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

string valid_yes(){// checks if the user has given an valid input for y|n
    bool again;
    string operation;

    do {
        cin >> operation;
        operation = maiusculo(operation);
        if (operation != "Y" && operation != "N") {
            again = true;
            cout << "Invalid input. Try again: ";
        }
        else
            again = false;
    } while (again);
    return operation;
}  